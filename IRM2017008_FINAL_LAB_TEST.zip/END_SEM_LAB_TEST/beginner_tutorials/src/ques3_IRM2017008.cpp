#include "ros/ros.h"
#include "geometry_msgs/Twist.h"
#include "turtlesim/Pose.h"
#include <sstream>
#include <bits/stdc++.h>
#include <turtlesim/Spawn.h>
#include <pthread.h>
#include <cstdlib>

using namespace std;

map<pair<double,double>,int> visited_point1;
map<pair<double,double>,int> visited_point2;

ros::Publisher velocity_publisher,velocity_publisher1,velocity_publisher2;
ros::Subscriber pose_subscriber,pose_subscriber1,pose_subscriber2;
turtlesim::Pose turtlesim_pose,turtlesim_pose1,turtlesim_pose2;

const double PI = 3.14159265359;

double robot_radius=0.5;
double KATT=10000.0;
double KREP=10000.0;
double D_REP=4*robot_radius;
double D_ATT=2*robot_radius;

void move(double speed, double distance, bool isForward,ros::Publisher velocity_publisher11);
void rotate(double angular_speed, double angle, bool cloclwise,ros::Publisher velocity_publisher11);
double degrees2radians(double angle_in_degrees);		
void poseCallback1(const turtlesim::Pose::ConstPtr & pose_message);
void poseCallback2(const turtlesim::Pose::ConstPtr & pose_message);

void *thread1(void *threadid){
	cout<<"In Thread 1\n";
	double final_x,final_y;
	final_x=2.0;
	final_y=2.0;
	double obstacle_x,obstacle_y;
	ros::Rate loop_rate(50);
	while(1){
		obstacle_x=turtlesim_pose2.x;
		obstacle_y=turtlesim_pose2.y;
		double cur_x=turtlesim_pose1.x;
	    double cur_y=turtlesim_pose1.y;

		double dist=pow(pow(final_x-cur_x,2)+pow(final_y-cur_y,2),0.5);


	    
	    pair<double,double> cord=make_pair(cur_x,cur_y);
	    if(visited_point1.find(cord)!=visited_point1.end())
	        visited_point1[cord]=visited_point1[cord]+1;
	    else
	        visited_point1[cord]=1;

	    double d_from_goal=pow(pow(cur_x-final_x,2)+pow(cur_y-final_y,2),0.5);
	    double F_Att_x=0,F_Att_y=0;
	    if(d_from_goal<=D_ATT){
	        F_Att_x=-KATT*(cur_x-final_x);
	        F_Att_y=-KATT*(cur_y-final_y);
	    }
	    else{
	        F_Att_x=(-KATT*4*D_ATT*(cur_x-final_x))/d_from_goal;
	        F_Att_y=(-KATT*4*D_ATT*(cur_y-final_y))/d_from_goal;
    	}

    	double step=0.2;

    	double d_from_rep=pow(pow(cur_x-obstacle_x,2)+pow(cur_y-obstacle_y,2),0.5)-2*robot_radius;
	    double F_Rep_x=0,F_Rep_y=0,dist_mul;
	    if(d_from_rep<=D_REP){
	        dist_mul=(1/d_from_rep)-(1/D_REP);
	        F_Rep_x=(KREP*dist_mul*(cur_x-obstacle_x))/pow(d_from_rep,1);
	        F_Rep_y=(KREP*dist_mul*(cur_y-obstacle_y))/pow(d_from_rep,1);
	        step=0.2;
	    }
	    else{
	        F_Rep_x=0;
	        F_Rep_y=0;
	    }
	    double F_Res_x=F_Att_x+F_Rep_x;
    	double F_Res_y=F_Att_y+F_Rep_y;
    	double F_Mag=pow(pow(F_Res_x,2)+pow(F_Res_y,2),0.5);
    	double x,y;
    	if(F_Mag!=0){
	        x=(F_Res_x/F_Mag);
	        y=(F_Res_y/F_Mag);
	    }
	    else{
	        //PERBUTATION
	        cout<<"Zero Force\n";
	        break;
	    }
	    cout<<"---------------\n";
	    cout<<F_Att_x<<" "<<F_Att_y<<endl;
	    cout<<F_Res_x<<" "<<F_Res_y<<endl;
	    cout<<x<<" "<<y<<endl;
	    double theta1=atan2(y,x);
		if(theta1<0.0)
			theta1=theta1+2*PI;
		double theta2=turtlesim_pose1.theta;
		int flag=0;
		if(theta1>theta2)
			flag=0;
		else
			flag=1;
		theta1=abs(theta1-theta2);
		if(theta1>PI && theta1<=(2*PI)){
			theta1=2*PI-theta1;
			if(flag==0)
				flag=1;
			else
				flag=0;
		}
		theta1=abs(theta1);
		cout<<theta1<<endl;
		if(theta1!=0){
			rotate(theta1,theta1,flag,velocity_publisher1);
			loop_rate.sleep();
	    	ros::spinOnce();
		}
	    move(step,step,true,velocity_publisher1);
	    loop_rate.sleep();
	    ros::spinOnce();
	}
	pthread_exit(NULL);
}

void *thread2(void *threadid){
	cout<<"In Thread 2\n";
	double final_x,final_y;
	final_x=5.54+2.101;
	final_y=5.54+2.101;
	double obstacle_x,obstacle_y;
	ros::Rate loop_rate(50);
	while(1){
		obstacle_x=turtlesim_pose1.x;
		obstacle_y=turtlesim_pose1.y;
		double cur_x=turtlesim_pose2.x;
	    double cur_y=turtlesim_pose2.y;

		double dist=pow(pow(final_x-cur_x,2)+pow(final_y-cur_y,2),0.5);

	    
	    pair<double,double> cord=make_pair(cur_x,cur_y);
	    if(visited_point2.find(cord)!=visited_point2.end())
	        visited_point2[cord]=visited_point2[cord]+1;
	    else
	        visited_point2[cord]=1;

	    double d_from_goal=pow(pow(cur_x-final_x,2)+pow(cur_y-final_y,2),0.5);
	    double F_Att_x=0,F_Att_y=0;
	    if(d_from_goal<=D_ATT){
	        F_Att_x=-KATT*(cur_x-final_x);
	        F_Att_y=-KATT*(cur_y-final_y);
	    }
	    else{
	        F_Att_x=(-KATT*4*D_ATT*(cur_x-final_x))/d_from_goal;
	        F_Att_y=(-KATT*4*D_ATT*(cur_y-final_y))/d_from_goal;
    	}

    	double step=0.2;

    	double d_from_rep=pow(pow(cur_x-obstacle_x,2)+pow(cur_y-obstacle_y,2),0.5)-2*robot_radius;
	    double F_Rep_x=0,F_Rep_y=0,dist_mul;
	    if(d_from_rep<=D_REP){
	        dist_mul=(1/d_from_rep)-(1/D_REP);
	        F_Rep_x=(KREP*dist_mul*(cur_x-obstacle_x))/pow(d_from_rep,1);
	        F_Rep_y=(KREP*dist_mul*(cur_y-obstacle_y))/pow(d_from_rep,1);
	        step=0.2;
	    }
	    else{
	        F_Rep_x=0;
	        F_Rep_y=0;
	    }
	    double F_Res_x=F_Att_x+F_Rep_x;
    	double F_Res_y=F_Att_y+F_Rep_y;
    	double F_Mag=pow(pow(F_Res_x,2)+pow(F_Res_y,2),0.5);
    	double x,y;
    	if(F_Mag!=0){
	        x=(F_Res_x/F_Mag);
	        y=(F_Res_y/F_Mag);
	    }
	    else{
	        //PERBUTATION
	        cout<<"Zero Force\n";
	        break;
	    }


	    double theta1=atan2(y,x);
		if(theta1<0.0)
			theta1=theta1+2*PI;
		double theta2=turtlesim_pose2.theta;
		int flag=0;
		if(theta1>theta2)
			flag=0;
		else
			flag=1;
		theta1=abs(theta1-theta2);

		if(theta1>PI && theta1<=(2*PI)){
			theta1=2*PI-theta1;
			if(flag==0)
				flag=1;
			else
				flag=0;
		}
		theta1=abs(theta1);
		if(theta1!=0){
			rotate(theta1,theta1,flag,velocity_publisher2);
			loop_rate.sleep();
	    	ros::spinOnce();
		}
	    move(step,step,true,velocity_publisher2);
	    loop_rate.sleep();
	    ros::spinOnce();
	}
	pthread_exit(NULL);
}


int main(int argc, char **argv)
{
	// Initiate new ROS node named "talker"
	ros::init(argc, argv, "turtlesim_go_to_goal");
	ros::NodeHandle n;

	velocity_publisher1 = n.advertise<geometry_msgs::Twist>("/turtle1/cmd_vel", 1000);
	pose_subscriber1 = n.subscribe("/turtle1/pose", 10, poseCallback1);
	ros::Rate loop_rate(50);

	ros::ServiceClient spawnClient = n.serviceClient<turtlesim::Spawn>("spawn");

   turtlesim::Spawn::Request req;
   turtlesim::Spawn::Response resp;

   req.x = 2.0;
   req.y = 2.0;
   req.theta = 0;
   req.name = "turtle2";

   ros::service::waitForService("spawn", ros::Duration(5));
   bool success = spawnClient.call(req,resp);

   if(success)
       ROS_INFO_STREAM("Spawned turtle named "<< resp.name);
   else
       ROS_ERROR_STREAM("Failed to spawn.");

    velocity_publisher2 = n.advertise<geometry_msgs::Twist>("/turtle2/cmd_vel", 1000);
	pose_subscriber2 = n.subscribe("/turtle2/pose", 10, poseCallback2);


	rotate(PI/4,PI/4,0,velocity_publisher1);
	loop_rate.sleep();
	ros::spinOnce();
    move(0.2,4,true,velocity_publisher1);
    loop_rate.sleep();
    ros::spinOnce();
  
	pthread_t t1,t2;
	void *status;

	pthread_create(&t1,NULL,thread1,(void *)1);
	pthread_create(&t1,NULL,thread2,(void *)2);

	pthread_join(t1,&status);
	pthread_join(t2,&status);

	return 0;
}

void move(double speed, double distance, bool isForward,ros::Publisher velocity_publisher11){
	geometry_msgs::Twist vel_msg;
   if (isForward)
	   vel_msg.linear.x =abs(speed);
   else
	   vel_msg.linear.x =-abs(speed);
   vel_msg.linear.y =0;
   vel_msg.linear.z =0;
   vel_msg.angular.x = 0;
   vel_msg.angular.y = 0;
   vel_msg.angular.z =0;

   double t0 = ros::Time::now().toSec();
   double current_distance = 0.0;
   ros::Rate loop_rate(50);
   do{
	   velocity_publisher11.publish(vel_msg);
	   double t1 = ros::Time::now().toSec();
	   current_distance = speed * (t1-t0);
	   ros::spinOnce();
	   loop_rate.sleep();
   }while(current_distance<distance);
   vel_msg.linear.x =0;
   velocity_publisher11.publish(vel_msg);

}

void rotate (double angular_speed, double relative_angle, bool clockwise,ros::Publisher velocity_publisher11){

	geometry_msgs::Twist vel_msg;
	   vel_msg.linear.x =0;
	   vel_msg.linear.y =0;
	   vel_msg.linear.z =0;
	   vel_msg.angular.x = 0;
	   vel_msg.angular.y = 0;
	   if (clockwise)
	   	vel_msg.angular.z =-abs(angular_speed);
	   else
	   	vel_msg.angular.z =abs(angular_speed);

	   double t0 = ros::Time::now().toSec();
	   double current_angle = 0.0;
	   ros::Rate loop_rate(50);
	   do{
		   velocity_publisher11.publish(vel_msg);
		   double t1 = ros::Time::now().toSec();
		   current_angle = angular_speed * (t1-t0);
		   ros::spinOnce();
		   loop_rate.sleep();
	   }while(current_angle<relative_angle);
	   vel_msg.angular.z =0;
	   velocity_publisher11.publish(vel_msg);
}

double degrees2radians(double angle_in_degrees){
	return angle_in_degrees *PI /180.0;
}

void poseCallback1(const turtlesim::Pose::ConstPtr & pose_message){
	turtlesim_pose1.x=pose_message->x;
	turtlesim_pose1.y=pose_message->y;
	turtlesim_pose1.theta=pose_message->theta;
}

void poseCallback2(const turtlesim::Pose::ConstPtr & pose_message){
	turtlesim_pose2.x=pose_message->x;
	turtlesim_pose2.y=pose_message->y;
	turtlesim_pose2.theta=pose_message->theta;
}
