#include "ros/ros.h"
#include "geometry_msgs/Twist.h"
#include "turtlesim/Pose.h"
#include <sstream>
#include <bits/stdc++.h>
#include <turtlesim/Spawn.h>
#include <pthread.h>
#include <cstdlib>
#include <map>

using namespace std;

vector<pair<int,int>> goals;
map<int,pair<double,double>> pos;

ros::Publisher velocity_publisher,velocity_publisher1,velocity_publisher2,velocity_publisher3,velocity_publisher4;
ros::Subscriber pose_subscriber,pose_subscriber1,pose_subscriber2,pose_subscriber3,pose_subscriber4;
turtlesim::Pose turtlesim_pose,turtlesim_pose1,turtlesim_pose2,turtlesim_pose3,turtlesim_pose4;

const double PI = 3.14159265359;

void move(double speed, double distance, bool isForward,ros::Publisher velocity_publisher11);
void rotate(double angular_speed, double angle, bool cloclwise,ros::Publisher velocity_publisher11);
double degrees2radians(double angle_in_degrees);		
void poseCallback1(const turtlesim::Pose::ConstPtr & pose_message);	
void poseCallback2(const turtlesim::Pose::ConstPtr & pose_message);	
void poseCallback3(const turtlesim::Pose::ConstPtr & pose_message);	
void poseCallback4(const turtlesim::Pose::ConstPtr & pose_message);	

void *thread1(void *threadid){
	cout<<"In Thread 1\n";
	ros::Rate loop_rate(5);
	while(1){
		double sx=0.0,sy=0.0,x,y;
		for(int i=1;i<=4;i++){
			if(i==1){
				x=pos[i].first;
				y=pos[i].second;
				continue;
			}
			sx+=pos[i].first;
			sy+=pos[i].second;
		}
		sx=sx/3;
		sy=sy/3;

		double theta1=atan2((sy-y),(sx-x));
		if(theta1<0.0)
			theta1=theta1+2*PI;
		double theta2=turtlesim_pose1.theta;
		int flag=0;
		if(theta1>theta2)
			flag=0;
		else
			flag=1;
		theta1=abs(theta1-theta2);
		rotate(theta1,theta1,flag,velocity_publisher1);
		loop_rate.sleep();
	    ros::spinOnce();
	    move(0.2,0.2,true,velocity_publisher1);
	    loop_rate.sleep();
	    ros::spinOnce();
	}
	pthread_exit(NULL);
}

void *thread2(void *threadid){
	cout<<"In Thread 2\n";
	ros::Rate loop_rate(5);
	while(1){
		double sx=0.0,sy=0.0,x,y;
		for(int i=1;i<=4;i++){
			if(i==2){
				x=pos[i].first;
				y=pos[i].second;
				continue;
			}
			sx+=pos[i].first;
			sy+=pos[i].second;
		}
		sx=sx/3;
		sy=sy/3;

		double theta1=atan2((sy-y),(sx-x));
		if(theta1<0.0)
			theta1=theta1+2*PI;
		double theta2=turtlesim_pose2.theta;
		int flag=0;
		if(theta1>theta2)
			flag=0;
		else
			flag=1;
		theta1=abs(theta1-theta2);
		rotate(theta1,theta1,flag,velocity_publisher2);
		loop_rate.sleep();
	    ros::spinOnce();
	    move(0.2,0.2,true,velocity_publisher2);
	    loop_rate.sleep();
	    ros::spinOnce();
	}
	pthread_exit(NULL);
}

void *thread3(void *threadid){
	cout<<"In Thread 3\n";
	ros::Rate loop_rate(5);
	while(1){
		double sx=0.0,sy=0.0,x,y;
		for(int i=1;i<=4;i++){
			if(i==3){
				x=pos[i].first;
				y=pos[i].second;
				continue;
			}
			sx+=pos[i].first;
			sy+=pos[i].second;
		}
		sx=sx/3;
		sy=sy/3;

		double theta1=atan2((sy-y),(sx-x));
		if(theta1<0.0)
			theta1=theta1+2*PI;
		double theta2=turtlesim_pose3.theta;
		int flag=0;
		if(theta1>theta2)
			flag=0;
		else
			flag=1;
		theta1=abs(theta1-theta2);
		rotate(theta1,theta1,flag,velocity_publisher3);
		loop_rate.sleep();
	    ros::spinOnce();
	    move(0.2,0.2,true,velocity_publisher3);
	    loop_rate.sleep();
	    ros::spinOnce();
	}
	pthread_exit(NULL);
}


void *thread4(void *threadid){
	cout<<"In Thread 4\n";
	ros::Rate loop_rate(5);
	while(1){
		double sx=0.0,sy=0.0,x,y;
		for(int i=1;i<=4;i++){
			if(i==4){
				x=pos[i].first;
				y=pos[i].second;
				continue;
			}
			sx+=pos[i].first;
			sy+=pos[i].second;
		}
		sx=sx/3;
		sy=sy/3;

		double theta1=atan2((sy-y),(sx-x));
		if(theta1<0.0)
			theta1=theta1+2*PI;
		double theta2=turtlesim_pose4.theta;
		int flag=0;
		if(theta1>theta2)
			flag=0;
		else
			flag=1;
		theta1=abs(theta1-theta2);
		rotate(theta1,theta1,flag,velocity_publisher4);
		loop_rate.sleep();
	    ros::spinOnce();
	    move(0.2,0.2,true,velocity_publisher4);
	    loop_rate.sleep();
	    ros::spinOnce();
	}
	pthread_exit(NULL);
}

void *pos_update_thread(void *threadid){
	while(1){
		double x,y;
		x=turtlesim_pose1.x;
		y=turtlesim_pose1.y;
		pos[1]=make_pair(x,y);

		x=turtlesim_pose2.x;
		y=turtlesim_pose2.y;
		pos[2]=make_pair(x,y);

		x=turtlesim_pose3.x;
		y=turtlesim_pose3.y;
		pos[3]=make_pair(x,y);

		x=turtlesim_pose4.x;
		y=turtlesim_pose4.y;
		pos[4]=make_pair(x,y);
	}
	pthread_exit(NULL);
}

int main(int argc, char **argv)
{
	// Initiate new ROS node named "talker"
	ros::init(argc, argv, "turtlesim_ellipse");
	ros::NodeHandle n;
	double speed, angular_speed;
	double distance, angle;
	bool isForward, clockwise;
	

	int index=0;

	velocity_publisher1 = n.advertise<geometry_msgs::Twist>("/turtle1/cmd_vel", 1000);
	pose_subscriber1 = n.subscribe("/turtle1/pose", 10, poseCallback1);
	ros::Rate loop_rate(5);


	ros::ServiceClient spawnClient
       = n.serviceClient<turtlesim::Spawn>("spawn");

   turtlesim::Spawn::Request req;
   turtlesim::Spawn::Response resp;

   req.x = 7.07872;
   req.y = 6.44704;
   req.theta = PI/2;
   req.name = "turtle2";

   ros::service::waitForService("spawn", ros::Duration(5));
   bool success = spawnClient.call(req,resp);

   if(success){
       ROS_INFO_STREAM("Spawned a turtle named "
                       << resp.name);
   }else{
       ROS_ERROR_STREAM("Failed to spawn.");
   }

   req.x = 5.61304;
   req.y = 7.23722;
   req.theta = PI;
   req.name = "turtle3";

   ros::service::waitForService("spawn", ros::Duration(5));
   success = spawnClient.call(req,resp);

   if(success){
       ROS_INFO_STREAM("Spawned a turtle named "
                       << resp.name);
   }else{
       ROS_ERROR_STREAM("Failed to spawn.");
   }

   req.x = 4.26807;
   req.y = 6.32745;
   req.theta = 3*(PI/2);
   req.name = "turtle4";

   ros::service::waitForService("spawn", ros::Duration(5));
   success = spawnClient.call(req,resp);

   if(success){
       ROS_INFO_STREAM("Spawned a turtle named "
                       << resp.name);
   }else{
       ROS_ERROR_STREAM("Failed to spawn.");
   }


   velocity_publisher2 = n.advertise<geometry_msgs::Twist>("/turtle2/cmd_vel", 1000);
	pose_subscriber2 = n.subscribe("/turtle2/pose", 10, poseCallback2);

	velocity_publisher3 = n.advertise<geometry_msgs::Twist>("/turtle3/cmd_vel", 1000);
	pose_subscriber3 = n.subscribe("/turtle3/pose", 10, poseCallback3);

	velocity_publisher4 = n.advertise<geometry_msgs::Twist>("/turtle4/cmd_vel", 1000);
	pose_subscriber4 = n.subscribe("/turtle4/pose", 10, poseCallback4);

	double x,y;
	x=turtlesim_pose1.x;
	y=turtlesim_pose1.y;
	pos[1]=make_pair(x,y);

	x=turtlesim_pose2.x;
	y=turtlesim_pose2.y;
	pos[2]=make_pair(x,y);

	x=turtlesim_pose3.x;
	y=turtlesim_pose3.y;
	pos[3]=make_pair(x,y);

	x=turtlesim_pose4.x;
	y=turtlesim_pose4.y;
	pos[4]=make_pair(x,y);
  
	pthread_t t1,t2,t3,t4,t5;
	void *status;

	pthread_create(&t5,NULL,pos_update_thread,(void *)5);

	pthread_create(&t1,NULL,thread1,(void *)1);
	
	pthread_create(&t2,NULL,thread2,(void *)2);

	pthread_create(&t3,NULL,thread3,(void *)3);

	pthread_create(&t4,NULL,thread4,(void *)4);

	pthread_join(t1,&status);

	pthread_join(t2,&status);
	
	pthread_join(t3,&status);

	pthread_join(t4,&status);

	pthread_join(t5,&status);

	return 0;
}

void move(double speed, double distance, bool isForward,ros::Publisher velocity_publisher11){
	geometry_msgs::Twist vel_msg;
   if (isForward)
	   vel_msg.linear.x =abs(speed);
   else
	   vel_msg.linear.x =-abs(speed);
   vel_msg.linear.y =0;
   vel_msg.linear.z =0;
   vel_msg.angular.x = 0;
   vel_msg.angular.y = 0;
   vel_msg.angular.z =0;

   double t0 = ros::Time::now().toSec();
   double current_distance = 0.0;
   ros::Rate loop_rate(100);
   do{
	   velocity_publisher11.publish(vel_msg);
	   double t1 = ros::Time::now().toSec();
	   current_distance = speed * (t1-t0);
	   ros::spinOnce();
	   loop_rate.sleep();
   }while(current_distance<distance);
   vel_msg.linear.x =0;
   velocity_publisher11.publish(vel_msg);

}

void rotate (double angular_speed, double relative_angle, bool clockwise,ros::Publisher velocity_publisher11){

	geometry_msgs::Twist vel_msg;
	   vel_msg.linear.x =0;
	   vel_msg.linear.y =0;
	   vel_msg.linear.z =0;
	   vel_msg.angular.x = 0;
	   vel_msg.angular.y = 0;
	   if (clockwise)
	   	vel_msg.angular.z =-abs(angular_speed);
	   else
	   	vel_msg.angular.z =abs(angular_speed);

	   double t0 = ros::Time::now().toSec();
	   double current_angle = 0.0;
	   ros::Rate loop_rate(1000);
	   do{
		   velocity_publisher11.publish(vel_msg);
		   double t1 = ros::Time::now().toSec();
		   current_angle = angular_speed * (t1-t0);
		   ros::spinOnce();
		   loop_rate.sleep();
	   }while(current_angle<relative_angle);
	   vel_msg.angular.z =0;
	   velocity_publisher11.publish(vel_msg);
}

double degrees2radians(double angle_in_degrees){
	return angle_in_degrees *PI /180.0;
}



void poseCallback1(const turtlesim::Pose::ConstPtr & pose_message){
	turtlesim_pose1.x=pose_message->x;
	turtlesim_pose1.y=pose_message->y;
	turtlesim_pose1.theta=pose_message->theta;
}
void poseCallback2(const turtlesim::Pose::ConstPtr & pose_message){
	turtlesim_pose2.x=pose_message->x;
	turtlesim_pose2.y=pose_message->y;
	turtlesim_pose2.theta=pose_message->theta;
}
void poseCallback3(const turtlesim::Pose::ConstPtr & pose_message){
	turtlesim_pose3.x=pose_message->x;
	turtlesim_pose3.y=pose_message->y;
	turtlesim_pose3.theta=pose_message->theta;
}
void poseCallback4(const turtlesim::Pose::ConstPtr & pose_message){
	turtlesim_pose4.x=pose_message->x;
	turtlesim_pose4.y=pose_message->y;
	turtlesim_pose4.theta=pose_message->theta;
}
