#include "ros/ros.h"
#include "std_msgs/String.h"

#include <bits/stdc++.h>

using namespace std;

void chatterCallback5(const std_msgs::String::ConstPtr& msg)
{
string str = msg->data.c_str();
istringstream ss(str);
string word,ans_str="";
int num;
while (ss >> word) 
{
num = stoi(word);
ans_str = ans_str + to_string(num) + " " ;
}
char* c = const_cast<char*>(ans_str.c_str());
ROS_INFO("I heard: %s on Channel 5", c);
}

int main(int argc, char **argv)
{
  ros::init(argc, argv, "prog1");
  ros::NodeHandle n;
  ros::Subscriber sub = n.subscribe("channel5", 1000, chatterCallback5);
  ros::Publisher chatter_pub=n.advertise<std_msgs::String>("channel1", 1000);
  
  //ros::spin();
  ros::Rate loop_rate(1);
  int count = 0;
  while (ros::ok())
  {
    std_msgs::String msg;

    std::stringstream ss;
    for(int i=1;i<=5;i++)
    {
        if(i==0)
            ss << i ;
        else
            ss << " " << i ;
    }
    msg.data = ss.str();

    ROS_INFO("SENT : %s", msg.data.c_str());
    chatter_pub.publish(msg);

    ros::Subscriber sub = n.subscribe("channel5", 1000, chatterCallback5);

    ros::spinOnce();

    loop_rate.sleep();
    ++count;
  }


  return 0;
}

