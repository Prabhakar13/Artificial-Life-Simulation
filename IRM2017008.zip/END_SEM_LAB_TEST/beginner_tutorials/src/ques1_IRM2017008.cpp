#include "ros/ros.h"
#include "geometry_msgs/Twist.h"
#include "turtlesim/Pose.h"
#include <sstream>
#include <bits/stdc++.h>
#include <turtlesim/Spawn.h>
#include <pthread.h>
#include <cstdlib>

using namespace std;

ros::Publisher velocity_publisher,velocity_publisher1;
ros::Subscriber pose_subscriber,pose_subscriber1;
turtlesim::Pose turtlesim_pose,turtlesim_pose1;

const double PI = 3.14159265359;
double goal_x,goal_y;

void move(double speed, double distance, bool isForward,ros::Publisher velocity_publisher11);
void rotate(double angular_speed, double angle, bool cloclwise,ros::Publisher velocity_publisher11);
double degrees2radians(double angle_in_degrees);		
void poseCallback1(const turtlesim::Pose::ConstPtr & pose_message);

void *thread1(void *threadid){
	cout<<"In Thread 1\n";
	ros::Rate loop_rate(5);
	while(1){
		double sx=0.0,sy=0.0,x,y;

		sx=goal_x;
		sy=goal_y;

		x=turtlesim_pose1.x;
		y=turtlesim_pose1.y;

		double dist=pow(pow(sx-x,2)+pow(sy-y,2),0.5);

		cout<<sx<<" "<<sy<<" "<<x<<" "<<y<<" "<<dist<<endl;

		if(dist<0.1){
			rotate(turtlesim_pose1.theta,turtlesim_pose1.theta,1,velocity_publisher1);
	    	break;
		}

		double theta1=atan2((sy-y),(sx-x));
		if(theta1<0.0)
			theta1=theta1+2*PI;
		double theta2=turtlesim_pose1.theta;
		int flag=0;
		if(theta1>theta2)
			flag=0;
		else
			flag=1;
		theta1=abs(theta1-theta2);
		if(theta1>PI){
			theta1=2*PI-theta1;
			if(flag==0)
				flag=1;
			else
				flag=0;
		}
		if(theta1!=0){
			rotate(theta1,theta1,flag,velocity_publisher1);
			loop_rate.sleep();
	    	ros::spinOnce();
		}
	    move(0.2,0.2,true,velocity_publisher1);
	    loop_rate.sleep();
	    ros::spinOnce();
	}
	pthread_exit(NULL);
}

int main(int argc, char **argv)
{
	// Initiate new ROS node named "talker"
	ros::init(argc, argv, "turtlesim_go_to_goal");
	ros::NodeHandle n;

	velocity_publisher1 = n.advertise<geometry_msgs::Twist>("/turtle1/cmd_vel", 1000);
	pose_subscriber1 = n.subscribe("/turtle1/pose", 10, poseCallback1);
	ros::Rate loop_rate(5);

	double x,y;
	x=turtlesim_pose1.x;
	y=turtlesim_pose1.y;


	ros::ServiceClient spawnClient = n.serviceClient<turtlesim::Spawn>("spawn");

   turtlesim::Spawn::Request req;
   turtlesim::Spawn::Response resp;

   goal_x=x+3.0;
   goal_y=y+2.0;

   req.x = goal_x;
   req.y = goal_y;
   req.theta = 0;
   req.name = "destination_turtle";

   ros::service::waitForService("spawn", ros::Duration(5));
   bool success = spawnClient.call(req,resp);

   if(success)
       ROS_INFO_STREAM("Spawned destination turtle named "<< resp.name);
   else
       ROS_ERROR_STREAM("Failed to spawn.");
  
	pthread_t t1;
	void *status;

	pthread_create(&t1,NULL,thread1,(void *)1);

	pthread_join(t1,&status);

	return 0;
}

void move(double speed, double distance, bool isForward,ros::Publisher velocity_publisher11){
	geometry_msgs::Twist vel_msg;
   if (isForward)
	   vel_msg.linear.x =abs(speed);
   else
	   vel_msg.linear.x =-abs(speed);
   vel_msg.linear.y =0;
   vel_msg.linear.z =0;
   vel_msg.angular.x = 0;
   vel_msg.angular.y = 0;
   vel_msg.angular.z =0;

   double t0 = ros::Time::now().toSec();
   double current_distance = 0.0;
   ros::Rate loop_rate(100);
   do{
	   velocity_publisher11.publish(vel_msg);
	   double t1 = ros::Time::now().toSec();
	   current_distance = speed * (t1-t0);
	   ros::spinOnce();
	   loop_rate.sleep();
   }while(current_distance<distance);
   vel_msg.linear.x =0;
   velocity_publisher11.publish(vel_msg);

}

void rotate (double angular_speed, double relative_angle, bool clockwise,ros::Publisher velocity_publisher11){

	geometry_msgs::Twist vel_msg;
	   vel_msg.linear.x =0;
	   vel_msg.linear.y =0;
	   vel_msg.linear.z =0;
	   vel_msg.angular.x = 0;
	   vel_msg.angular.y = 0;
	   if (clockwise)
	   	vel_msg.angular.z =-abs(angular_speed);
	   else
	   	vel_msg.angular.z =abs(angular_speed);

	   double t0 = ros::Time::now().toSec();
	   double current_angle = 0.0;
	   ros::Rate loop_rate(1000);
	   do{
		   velocity_publisher11.publish(vel_msg);
		   double t1 = ros::Time::now().toSec();
		   current_angle = angular_speed * (t1-t0);
		   ros::spinOnce();
		   loop_rate.sleep();
	   }while(current_angle<relative_angle);
	   vel_msg.angular.z =0;
	   velocity_publisher11.publish(vel_msg);
}

double degrees2radians(double angle_in_degrees){
	return angle_in_degrees *PI /180.0;
}

void poseCallback1(const turtlesim::Pose::ConstPtr & pose_message){
	turtlesim_pose1.x=pose_message->x;
	turtlesim_pose1.y=pose_message->y;
	turtlesim_pose1.theta=pose_message->theta;
}
