#include<ros/ros.h>
#include"geometry_msgs/Twist.h"
#include"geometry_msgs/Pose.h"
#include"turtlesim/Pose.h"
#include"sstream"
#include<bits/stdc++.h>

using namespace std;

vector<double> position;

void pose_callback(const turtlesim::Pose& msgIn){
	ROS_INFO_STREAM(std::setprecision(2)<<std::fixed
		<<"position = ("<<msgIn.x<<","<<msgIn.y<<")"
		<<" direction = "<<msgIn.theta
		);
	position.clear();
	position.push_back(msgIn.x);
	position.push_back(msgIn.y);
}

int main(int argc, char **argv)
{
	ros::init(argc,argv,"turtle_move");
	ros::NodeHandle n;
	ros::Subscriber sub=n.subscribe("/turtle1/pose",1000,pose_callback);
	ros::Publisher velocity_pub=n.advertise<geometry_msgs::Twist>("/turtle1/cmd_vel",1000);
	ros::Rate loop_rate(1);//1 msg per second

	srand(time(NULL));
	int count=0,val=1;
	while(ros::ok()){
		if(position.size()!=0)
		{
			geometry_msgs::Twist vel_msg;
			vel_msg.linear.x=0;
			vel_msg.linear.y=0;
			vel_msg.linear.z=0;

			vel_msg.angular.x=0;
			vel_msg.angular.y=0;
			vel_msg.angular.z=val;

			count++;
			if(count==90)
				val=0;

			velocity_pub.publish(vel_msg);
		}

		ros::Subscriber sub=n.subscribe("/turtle1/pose",1000,pose_callback);

		ros::spinOnce();

		loop_rate.sleep();

	}
	return 0;
}



