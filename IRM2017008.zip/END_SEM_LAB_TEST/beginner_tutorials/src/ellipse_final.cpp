#include "ros/ros.h"
#include "geometry_msgs/Twist.h"
#include "turtlesim/Pose.h"
#include <sstream>
#include <bits/stdc++.h>
#include <turtlesim/Spawn.h>

using namespace std;

vector<pair<int,int>> goals;

ros::Publisher velocity_publisher,velocity_publisher1,velocity_publisher2,velocity_publisher3,velocity_publisher4;
ros::Subscriber pose_subscriber,pose_subscriber1,pose_subscriber2,pose_subscriber3,pose_subscriber4;
turtlesim::Pose turtlesim_pose;

const double PI = 3.14159265359;

void move(double speed, double distance, bool isForward,ros::Publisher velocity_publisher11);
void rotate(double angular_speed, double angle, bool cloclwise,ros::Publisher velocity_publisher11);	//this will rotate the turtle at specified angle from its current angle
double degrees2radians(double angle_in_degrees);		
void poseCallback(const turtlesim::Pose::ConstPtr & pose_message);	//Callback fn everytime the turtle pose msg is published over the /turtle1/pose topic.


int main(int argc, char **argv)
{
	// Initiate new ROS node named "talker"
	ros::init(argc, argv, "turtlesim_cleaner");
	ros::NodeHandle n;
	double speed, angular_speed;
	double distance, angle;
	bool isForward, clockwise;
	

	int index=0;

	velocity_publisher1 = n.advertise<geometry_msgs::Twist>("/turtle1/cmd_vel", 1000);
	pose_subscriber1 = n.subscribe("/turtle1/pose", 10, poseCallback);	//call poseCallback everytime the turtle pose msg is published over the /turtle1/pose topic.
	ros::Rate loop_rate(5);


	ros::ServiceClient spawnClient
       = n.serviceClient<turtlesim::Spawn>("spawn");

	//Create the request and response objects.
   turtlesim::Spawn::Request req;
   turtlesim::Spawn::Response resp;

   req.x = 7.07872;
   req.y = 6.44704;
   req.theta = PI/2;
   req.name = "turtle2";

   ros::service::waitForService("spawn", ros::Duration(5));
   bool success = spawnClient.call(req,resp);

   if(success){
       ROS_INFO_STREAM("Spawned a turtle named "
                       << resp.name);
   }else{
       ROS_ERROR_STREAM("Failed to spawn.");
   }

   req.x = 5.61304;
   req.y = 7.23722;
   req.theta = PI;
   req.name = "turtle3";

   ros::service::waitForService("spawn", ros::Duration(5));
   success = spawnClient.call(req,resp);

   if(success){
       ROS_INFO_STREAM("Spawned a turtle named "
                       << resp.name);
   }else{
       ROS_ERROR_STREAM("Failed to spawn.");
   }

   req.x = 4.26807;
   req.y = 6.32745;
   req.theta = 3*(PI/2);
   req.name = "turtle4";

   ros::service::waitForService("spawn", ros::Duration(5));
   success = spawnClient.call(req,resp);

   if(success){
       ROS_INFO_STREAM("Spawned a turtle named "
                       << resp.name);
   }else{
       ROS_ERROR_STREAM("Failed to spawn.");
   }


   velocity_publisher2 = n.advertise<geometry_msgs::Twist>("/turtle2/cmd_vel", 1000);
	pose_subscriber2 = n.subscribe("/turtle2/pose", 10, poseCallback);

	velocity_publisher3 = n.advertise<geometry_msgs::Twist>("/turtle3/cmd_vel", 1000);
	pose_subscriber3 = n.subscribe("/turtle3/pose", 10, poseCallback);

	velocity_publisher4 = n.advertise<geometry_msgs::Twist>("/turtle4/cmd_vel", 1000);
	pose_subscriber4 = n.subscribe("/turtle4/pose", 10, poseCallback);

	double degree1=0.0,degree2=9.0,degree3=0.0,degree4=9.0;
	double iter1=1.0,iter2=1.0,iter3=1.0,iter4=1.0;
	double sum1=0.0,sum2=45.0,sum3=0.0,sum4=45.0;
    while(1){
  //   	void move(double speed, double distance, bool isForward);
		// void rotate(double angular_speed, double angle, bool cloclwise);
     	rotate(degrees2radians(2*degree1),degrees2radians(degree1),0,velocity_publisher1);
	    loop_rate.sleep();
	    ros::spinOnce();
	    move(0.2,0.1,true,velocity_publisher1);
	    loop_rate.sleep();
	    ros::spinOnce();

		rotate(degrees2radians(2*degree1),degrees2radians(degree1),0,velocity_publisher1);
	    loop_rate.sleep();
	    ros::spinOnce();
	    move(0.2,0.1,true,velocity_publisher1);
	    loop_rate.sleep();
	    ros::spinOnce();

	    sum1=sum1+degree1;
	    if(sum1==45.0){
	    	iter1=-iter1;
	    	sum1=0.0;
	    }
	    else
	    	degree1=degree1+iter1;


	    rotate(degrees2radians(2*degree2),degrees2radians(degree2),0,velocity_publisher2);
	    loop_rate.sleep();
	    ros::spinOnce();
	    move(0.2,0.1,true,velocity_publisher2);
	    loop_rate.sleep();
	    ros::spinOnce();

		rotate(degrees2radians(2*degree2),degrees2radians(degree2),0,velocity_publisher2);
	    loop_rate.sleep();
	    ros::spinOnce();
	    move(0.2,0.1,true,velocity_publisher2);
	    loop_rate.sleep();
	    ros::spinOnce();

	    sum2=sum2+degree2;
	    if(sum2==45.0){
	    	iter2=-iter2;
	    	sum2=0.0;
	    }
	    else
	    	degree2=degree2+iter2;


	    rotate(degrees2radians(2*degree3),degrees2radians(degree3),0,velocity_publisher3);
	    loop_rate.sleep();
	    ros::spinOnce();
	    move(0.2,0.1,true,velocity_publisher3);
	    loop_rate.sleep();
	    ros::spinOnce();

		rotate(degrees2radians(2*degree3),degrees2radians(degree3),0,velocity_publisher3);
	    loop_rate.sleep();
	    ros::spinOnce();
	    move(0.2,0.1,true,velocity_publisher3);
	    loop_rate.sleep();
	    ros::spinOnce();

	    sum3=sum3+degree3;
	    if(sum3==45.0){
	    	iter3=-iter3;
	    	sum3=0.0;
	    }
	    else
	    	degree3=degree3+iter3;


	    rotate(degrees2radians(2*degree4),degrees2radians(degree4),0,velocity_publisher4);
	    loop_rate.sleep();
	    ros::spinOnce();
	    move(0.2,0.1,true,velocity_publisher4);
	    loop_rate.sleep();
	    ros::spinOnce();

		rotate(degrees2radians(2*degree4),degrees2radians(degree4),0,velocity_publisher4);
	    loop_rate.sleep();
	    ros::spinOnce();
	    move(0.2,0.1,true,velocity_publisher4);
	    loop_rate.sleep();
	    ros::spinOnce();

	    sum4=sum4+degree4;
	    if(sum4==45.0){
	    	iter4=-iter4;
	    	sum4=0.0;
	    }
	    else
	    	degree4=degree4+iter4;
    }

	return 0;
}

void move(double speed, double distance, bool isForward,ros::Publisher velocity_publisher11){
	geometry_msgs::Twist vel_msg;
   //set a random linear velocity in the x-axis
   if (isForward)
	   vel_msg.linear.x =abs(speed);
   else
	   vel_msg.linear.x =-abs(speed);
   vel_msg.linear.y =0;
   vel_msg.linear.z =0;
   //set a random angular velocity in the y-axis
   vel_msg.angular.x = 0;
   vel_msg.angular.y = 0;
   vel_msg.angular.z =0;

   double t0 = ros::Time::now().toSec();
   double current_distance = 0.0;
   ros::Rate loop_rate(100);
   do{
	   velocity_publisher11.publish(vel_msg);
	   double t1 = ros::Time::now().toSec();
	   current_distance = speed * (t1-t0);
	   ros::spinOnce();
	   loop_rate.sleep();
	   //cout<<(t1-t0)<<", "<<current_distance <<", "<<distance<<endl;
   }while(current_distance<distance);
   vel_msg.linear.x =0;
   velocity_publisher11.publish(vel_msg);

}

void rotate (double angular_speed, double relative_angle, bool clockwise,ros::Publisher velocity_publisher11){

	geometry_msgs::Twist vel_msg;
	   //set a random linear velocity in the x-axis
	   vel_msg.linear.x =0;
	   vel_msg.linear.y =0;
	   vel_msg.linear.z =0;
	   //set a random angular velocity in the y-axis
	   vel_msg.angular.x = 0;
	   vel_msg.angular.y = 0;
	   if (clockwise)
	   	vel_msg.angular.z =-abs(angular_speed);
	   else
	   	vel_msg.angular.z =abs(angular_speed);

	   double t0 = ros::Time::now().toSec();
	   double current_angle = 0.0;
	   ros::Rate loop_rate(1000);
	   do{
		   velocity_publisher11.publish(vel_msg);
		   double t1 = ros::Time::now().toSec();
		   current_angle = angular_speed * (t1-t0);
		   ros::spinOnce();
		   loop_rate.sleep();
		   //cout<<(t1-t0)<<", "<<current_angle <<", "<<relative_angle<<endl;
	   }while(current_angle<relative_angle);
	   vel_msg.angular.z =0;
	   velocity_publisher11.publish(vel_msg);
}

/**
 *  converts angles from degree to radians  
 */

double degrees2radians(double angle_in_degrees){
	return angle_in_degrees *PI /180.0;
}



void poseCallback(const turtlesim::Pose::ConstPtr & pose_message){
	turtlesim_pose.x=pose_message->x;
	turtlesim_pose.y=pose_message->y;
	turtlesim_pose.theta=pose_message->theta;
}
