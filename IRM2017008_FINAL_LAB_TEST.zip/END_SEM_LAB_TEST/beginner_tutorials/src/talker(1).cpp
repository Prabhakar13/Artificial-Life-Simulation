// #include "ros/ros.h"
// #include "std_msgs/String.h"

// #include <sstream>
// int main(int argc, char **argv)
// {
//   ros::init(argc, argv, "talker");
//   ros::NodeHandle n;
//   ros::Publisher chatter_pub=n.advertise<std_msgs::String>("chatter", 1000);
//   ros::Rate loop_rate(10);
//   int count = 0;
//   while (ros::ok())
//   {
//     std_msgs::String msg;

//     std::stringstream ss;
//     for(int i=0;i<5;i++)
//     {
//         if(i==0)
//             ss << i ;
//         else
//             ss << " " << i ;
//     }
//     msg.data = ss.str();

//     ROS_INFO("%s", msg.data.c_str());
//     chatter_pub.publish(msg);

//     ros::spinOnce();

//     loop_rate.sleep();
//     ++count;
//   }


//   return 0;
// }


#include "ros/ros.h"
#include "std_msgs/String.h"

#include <bits/stdc++.h>

using namespace std;

void chatterCallback(const std_msgs::String::ConstPtr& msg)
{
string str = msg->data.c_str();
istringstream ss(str);
string word,ans_str="";
int num;
while (ss >> word) 
{
num = stoi(word);
ans_str = ans_str + to_string(num+1) + " " ;
}
char* c = const_cast<char*>(ans_str.c_str());
ROS_INFO("I heard: %s", c);
}

int main(int argc, char **argv)
{
  ros::init(argc, argv, "talker");
  ros::NodeHandle n;
  ros::Subscriber sub = n.subscribe("chatter1", 1000, chatterCallback);
  ros::Publisher chatter_pub=n.advertise<std_msgs::String>("chatter", 1000);
  
  //ros::spin();
  ros::Rate loop_rate(10);
  int count = 0;
  while (ros::ok())
  {
    std_msgs::String msg;

    std::stringstream ss;
    for(int i=0;i<5;i++)
    {
        if(i==0)
            ss << i ;
        else
            ss << " " << i ;
    }
    msg.data = ss.str();

    ROS_INFO("%s", msg.data.c_str());
    chatter_pub.publish(msg);

    ros::Subscriber sub = n.subscribe("chatter1", 1000, chatterCallback);

    ros::spinOnce();

    loop_rate.sleep();
    ++count;
  }


  return 0;
}

