#include "ros/ros.h"
#include "std_msgs/String.h"

#include <bits/stdc++.h>

using namespace std;

vector<int> arr;

void chatterCallback2(const std_msgs::String::ConstPtr& msg)
{
string str = msg->data.c_str();
istringstream ss(str);
string word,ans_str="";
int num;
arr.clear();
while (ss >> word) 
{
num = stoi(word);
ans_str = ans_str + to_string(num) + " " ;
arr.push_back(num);
}
char* c = const_cast<char*>(ans_str.c_str());
ROS_INFO("I heard: %s on Channel 2", c);
}

void chatterCallback3(const std_msgs::String::ConstPtr& msg)
{
string str = msg->data.c_str();
istringstream ss(str);
string word,ans_str="";
int num;
while (ss >> word) 
{
num = stoi(word);
ans_str = ans_str + to_string(num) + " " ;
}
char* c = const_cast<char*>(ans_str.c_str());
ROS_INFO("I heard: %s on Channel 3", c);
}

int main(int argc, char **argv)
{
  ros::init(argc, argv, "prog4");
  ros::NodeHandle n;
  ros::Subscriber sub1 = n.subscribe("channel2", 1000, chatterCallback2);
  ros::Subscriber sub3 = n.subscribe("channel3", 1000, chatterCallback3);
  ros::Publisher chatter_pub=n.advertise<std_msgs::String>("channel5", 1000);
  
  //ros::spin();
  ros::Rate loop_rate(1);
  int count = 0;
  while (ros::ok())
  {
    if(arr.size()!=0){
      std_msgs::String msg;

      std::stringstream ss;
      for(int i=0;i<arr.size();i++)
      {
          if(i==0)
              ss << arr[i] ;
          else
              ss << " " << arr[i] ;
      }
      msg.data = ss.str();

      ROS_INFO("SENT : %s", msg.data.c_str());
      chatter_pub.publish(msg);
    }

    ros::Subscriber sub1 = n.subscribe("channel2", 1000, chatterCallback2);
    ros::Subscriber sub3 = n.subscribe("channel3", 1000, chatterCallback3);

    ros::spinOnce();

    loop_rate.sleep();
    ++count;
  }


  return 0;
}

